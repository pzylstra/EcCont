## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(frame)
library(dplyr)
library(extraDistr)
library(kableExtra)
library(rmarkdown)

## ----params_input-------------------------------------------------------------
record <- 1
data(f_site)
data(f_structure)
data(f_flora)
data(f_traits)
input <- paramBuilder(f_site, f_structure, f_flora, f_traits, record)



## ----ffm_run, eval = FALSE, results= 'hide'-----------------------------------
#  ffm_run(input, db.path = "out.db", db.recreate = TRUE)

## ----db_load------------------------------------------------------------------
results<-ffm_db_load("out.db")

## ----flamesummaries-----------------------------------------------------------
results$FlameSummaries %>%
 kbl() %>% 
  kable_material(c("striped", "hover"))

## ----ignitionpaths------------------------------------------------------------
results$IgnitionPaths %>% 
  paged_table()

## ----ros----------------------------------------------------------------------
results$ROS %>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))

## ----runs---------------------------------------------------------------------
results$Runs %>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))

## ----sites--------------------------------------------------------------------
results$Sites%>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))

## ----strata-------------------------------------------------------------------
results$Strata%>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))

## ----surfaceresults-----------------------------------------------------------

results$SurfaceResults %>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))


